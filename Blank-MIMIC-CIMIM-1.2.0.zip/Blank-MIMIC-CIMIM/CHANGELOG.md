# Changelog

## 1.2.0 — 2026-11-02 (second audit; Python-free verification)

### Added
- **RUSSL lowering in the console's own toolchain** (`src/russl.js`): a port of
  `russl_reference.parse_russl` / `lower_russl`, rule for rule, with the same error codes. Loading a
  .russ now re-lowers its .russl source and refuses the file unless the stored IR is exactly that
  lowering. This closes the last check that only the Python tool could make.
- **No Python in the user-facing path.** `Verify R files.cmd` runs `tools/verify_r.mjs` on the
  portable Node from bytefoundry-0.99.2-win64, and `tools/make_r_templates.mjs` generates the
  R0/R1/R2 programs with `src/russl.js`. Python remains only in the test suite, as an independent
  cross-check (`test/verify_r_python.py`, `test/make_r_templates_python.py`, `test/ref_numpy.py`).
- `test/russl.test.mjs`: JS and Python lowering agree on 28 cases (12 corpus examples with
  byte-identical IR, 6 invalid vectors with the same error code, the 3 R templates, 7 mutations).
- Hostile tests: an edited IR with every id recomputed (only re-lowering can catch it) and six
  schema/strict-JSON cases; JS and Python refuse all 15 crafted containers.
- `test/page.test.cjs`: the built console in Chromium with software WebGPU. **The WebGPU backend is
  now verified**: bit-identical to both CPU engines, and the hologram holds on it.

### Fixed (second independent review)
- **The 1.2.0 build itself was broken during development**: the new scoped bundler dropped all but
  the first name of `export const A = …, B = …` lines, so the page failed at start-up. The bundler
  now takes each module's export list from Node's module loader, and `build.sh` ends with a browser
  smoke test of the built page.
- **Clicking Run or Compare while engines were still starting locked the console for good.** Controls
  stay locked until start-up finishes, every action guards a missing engine, and every busy section
  releases in `finally`.
- **The threaded engine's time limit killed long legitimate runs** (a 255-row, 80-step program in
  Z/3^13 was retired at 100 s). The limit is replaced by a progress watchdog: worker 0 counts finished
  rows in shared memory and a run stops only after 30 s with no progress.
- **Single-thread runs froze the page** (up to ~74 s at 5000 BF2 steps). The single-thread engine now
  runs in a worker in the browser. A new **Stop** button cancels a run on either CPU engine and
  leaves the engine usable. WebGPU read-back has a time limit and reports device loss as `broken`.
- **A stopped engine was not always retired** (the hologram check, and WebGPU after device loss). All
  engine calls go through one wrapper that retires stopped engines and falls back.
- **A pipeline that stopped part-way left misleading state** (fresh R1 shown stale, old R2 timing).
  The stage that did not finish and everything after it are cleared.
- **readRuss still accepted files the Python verifier refuses**: lone-surrogate strings, JSON with
  more than 100,000 values (only containers were counted), and schema violations (extra manifest
  keys, `hash: "md5"`, `container_mode`, descriptor `sparse: "yes"`). Every value is now counted,
  strings and keys must be well-formed Unicode, provenance must parse, and the corpus schemas are
  enforced (`src/schema.js`).
- **C engine:** `load_program` counts could wrap in u32 and `run(nt=0)` divided by zero; both refused.
- **Windows paths** in the tools and tests now use `fileURLToPath`.
- A replaced single-thread worker's late exit event could reject the next run (found while testing Stop).

### Changed
- The build gives every module its own scope (a small scoped bundler in `build.sh`), so modules can
  share helper names safely. Hashing and canonical JSON now live once, in `src/russl.js`.

## 1.1.0 — 2026-11-02 (audit and hardening)

LCUF-A compiler 0.3.1 (language LCUF-A/0.3 unchanged; every 1.0.0 program still compiles and gives the same results).

### Fixed
- **Engines disagreed on `addc` with a large constant in odd rings.** `a + c` wrapped at 2^32 in C and
  WGSL but not in the JS reference (131,070 of 131,072 words differed in Z/5^8). Constants for
  `addc`, `mulc` and `orc` are now reduced mod p^n by the compiler, and again inside each engine.
- **`ring p=5 n=0` was accepted** (a one-element ring). n must be at least 1.
- **The local server crashed on a malformed URL** (`/%E0%A4%A` threw an unhandled URIError and took
  the console down). It now answers 400; it also refuses sibling-folder escapes (`/../web-evil/…`),
  NUL bytes and methods other than GET/HEAD, and sends `nosniff` and `no-referrer`.
- **readRuss threw raw RangeError/TypeError on truncated or hostile files.** It now performs every
  structural check of `russ_container.verify_bytes` (size limits, manifest bounds, strict UTF-8 JSON,
  entry keys, safe and unique paths, record bounds, sorted records, no trailing data, tuple arity and
  order, identity/geometry/state profile, authorization and allow-list boundaries) and refuses with a
  clear `RussError`.
- **A worker that died left the threaded engine waiting forever.** Worker errors now reject the run
  and stop the engine; start-up has a 20 s limit.
- **Results could go stale silently.** Recompiling or restoring a program, or changing a step count,
  now marks R1 and R2 stale until the pipeline runs again.
- **Programs could change mid-run.** A run now snapshots both programs and step counts, and every
  control is disabled while a run, comparison or check is in progress.
- Engine and WGSL error text is escaped before it is shown.

- **The threaded engine could hang forever** (found by the independent review): a second run
  started while one was in flight, or a worker killed mid-run, left `run()` pending with every
  control disabled. Runs are now queued per engine, every run has a time limit, worker exits and
  unreadable messages count as failures, and a stopped engine is retired and the console falls back
  to one thread.
- **Seeding or loading R0 during a run could mislabel R1** (review): R1 could be computed from the old
  R0 while recording the new R0's tuple id. Seeding and loading now lock the controls, and a run
  snapshots R0 and refuses to finish if R0 changes underneath it.
- **readRuss accepted containers the Python verifier rejects** (review): identity profile,
  `arbitrary_code: true`, payload root, duplicate JSON keys, duplicated or unbound MSSL modules,
  geometry/descriptor axes, admission policy binding, a payload path named `constructor`, and a null
  FIELD_DEFINE argument. All are now refused, and JS and Python agree on every hostile test file.
  A file with any problem is no longer loaded as R0.
- **Engines disagreed on input words of 2^21 or more in odd rings** (review): all engines now refuse
  frames whose words exceed 20 bits.
- **canonicalJson sorted keys by UTF-16 unit, not code point, and accepted unsafe integers**
  (review): it now sorts by code point and refuses integers beyond 2^53.
- LCUF-A: `ring p=02` and register names such as `__proto__` or `undefined` are refused (review).
- Compare engines now checks every engine against the displayed R2 when it is current (review).
- The WebGPU wrapper releases its buffers when read-back fails (review).

### Hardened
- The C engine validates its own inputs: `configure` refuses non-prime p, n < 1, p^n > 2^21 and
  p = 2 with n ≠ 20; `load_program` refuses out-of-range ops, slots, `rot` and `modj` arguments and
  aliased outputs. Both return 0 and the JS wrapper reports the refusal.
- All engines refuse step counts outside 1…100,000 and inputs that are not 131,072 words.
- The parser caps source length (64 KB), argument digits and ring digits before testing primality.
- WebGPU runs inside validation and out-of-memory error scopes and stops cleanly when the device is lost.
- Loaded fields with bits above bit 19 are masked to 20 bits and the loss is reported.
- readRuss checks the IR's integrity without the Python tooling: `ir_id` and `source_sha256` must
  recompute, MSSL bindings must match their module digests, and the field must be 1,1,8,128,128 u32.

### Added
- **Check hologram:** for layers j = 1, 2, 4, 8, 12, 16, 20, runs BF1 on R0 reduced mod 2^j and
  compares the result's layer j with R1's stored layer j.
- Provenance in every R now records the console version and the LCUF-A compiler version.
- Version shown in the console header.
- New tests (31 engine and compiler, 13 container, 8 hostile-container parity): compiler diagnostics,
  constant reduction across all CPU engines, engine refusals, overlapping runs, a worker killed
  mid-run, truncated/oversized/trailing/escaping containers, and eight crafted containers that JS and
  the Python reference must both refuse.

## 1.0.0 — 2026-11-02
First release: R0 → BF1 (Z/2^20) → R1 → BF2 (Z/5^8) → R2, LCUF-A/0.3, Wasm 1-thread and
multi-thread engines, WebGPU kernel, RUSS 1.3 containers verified by the RUSSL reference tooling.
