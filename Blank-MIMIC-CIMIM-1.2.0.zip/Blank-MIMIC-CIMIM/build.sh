#!/bin/sh
# SPDX-License-Identifier: GPL-3.0-only
# Copyright (C) 2026 RUSSELL PHILIP SMITHSON
set -e
cd "$(dirname "$0")"
mkdir -p dist web
COMMON="--target=wasm32 -O3 -msimd128 -nostdlib -ffreestanding -Wall -Wl,--no-entry -Wl,--strip-all -Wl,-z,stack-size=65536"
clang $COMMON -Wl,--export-memory -Wl,--initial-memory=20971520 -o web/xpu.wasm src/xpu.c
clang $COMMON -DXPU_THREADS -matomics -mbulk-memory -Wl,--import-memory -Wl,--shared-memory \
  -Wl,--initial-memory=20971520 -Wl,--max-memory=20971520 -Wl,--export=__stack_pointer -o web/xpu-mt.wasm src/xpu.c
echo "built web/xpu.wasm ($(wc -c < web/xpu.wasm) B) web/xpu-mt.wasm ($(wc -c < web/xpu-mt.wasm) B)"
python3 - <<'PY'
import base64, re, json, os, subprocess
def bundle(paths):
    """Wrap each ES module in its own function scope; imports become destructuring of earlier modules."""
    out, names = [], {}
    for path in paths:
        key = path.split("/")[-1].replace(".js", "")
        src = open(path).read()
        imports = re.findall(r'^import \{([^}]*)\} from "\./([a-z0-9-]+)\.js";\n', src, flags=re.M)
        src = re.sub(r'^import [^\n]*\n', '', src, flags=re.M)
        # the export list comes from Node's own module loader, so no declaration form can be missed
        exported = json.loads(subprocess.check_output(["node", "--input-type=module", "-e",
            f"import * as m from {json.dumps(os.path.abspath(path))}; console.log(JSON.stringify(Object.keys(m)))"]))
        src = re.sub(r'^export \{[^}]*\};\n', '', src, flags=re.M)
        src = re.sub(r'^export ', '', src, flags=re.M)
        head = "".join(f"const {{ {names_} }} = __mod_{mod.replace('-', '_')};\n" for names_, mod in imports)
        out.append(f"const __mod_{key.replace('-', '_')} = (() => {{\n{head}{src}\nreturn {{ {', '.join(exported)} }};\n}})();")
        names[key] = exported
    expose = "".join(f"const {{ {', '.join(v)} }} = __mod_{k.replace('-', '_')};\n" for k, v in names.items() if k in ("lcufa", "engines", "russ"))
    return "\n".join(out) + "\n" + expose
mods = bundle(["src/lcufa.js", "src/russl.js", "src/schemas.js", "src/schema.js", "src/engines.js", "src/russ.js"])
page = open("src/page.html").read()
page = page.replace("%%MODULES%%", mods).replace("%%TEMPLATES%%", open("web/r-templates.json").read())
page = page.replace("%%XPU_B64%%", base64.b64encode(open("web/xpu.wasm","rb").read()).decode())
page = page.replace("%%XPU_MT_B64%%", base64.b64encode(open("web/xpu-mt.wasm","rb").read()).decode())
open("dist/plume-xpu-console.html", "w").write(page)
open("web/index.html", "w").write('<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n</head>\n<body>\n' + page + '\n</body>\n</html>\n')
print("built web/index.html and dist/plume-xpu-console.html,", len(page)//1024, "KB")
PY
# smoke test: the built page must start, run the pipeline and report no errors
if [ "${SKIP_SMOKE:-0}" != "1" ]; then node tools/smoke.cjs; fi
