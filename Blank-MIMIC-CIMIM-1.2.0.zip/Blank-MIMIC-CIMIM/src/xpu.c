/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 RUSSELL PHILIP SMITHSON */
/*
 * xpu.c - ByteFoundry virtual XPU: the LCUF-A/0.3 array engine.
 *
 * LCUF-A programs are compiled (in JS) to a flat instruction list and run here.
 * Each instruction is a whole-array kernel over a 8 x 128 x 128 frame of u32
 * words in the ring Z/p^n (NumPy-style: one native loop per operation).
 *
 * Threading: the same module runs in N workers over one shared memory. Worker t
 * owns rows [t*H/N, (t+1)*H/N) and every instruction ends at a barrier, so
 * neighbour reads (nsum, life) always see a complete previous array.
 * Built twice: plain (single thread) and threaded (shared memory + atomics).
 *
 * Bit-exact with the WGSL backend: all arithmetic is u32 with explicit
 * reductions; mulmod uses 10-bit chunks so no product exceeds 2^32.
 */
typedef unsigned int u32;
typedef unsigned long long u64;
#define EXPORT(name) __attribute__((export_name(#name)))

#define L 8
#define H 128
#define W 128
#define CELLS (H * W)
#define WORDS (CELLS * L)
#define NSLOT 16
#define MAXI 256

/* slot layout is chunky like the TIFF frame: index = (y*W + x)*L + lane */
static u32 slot[NSLOT][WORDS] __attribute__((aligned(16)));
static u32 prog[MAXI * 5];               /* op, out, a, b, c */
static u32 ninit, nstep, nfinal;         /* instruction counts per phase */
static u32 g_p = 2, g_n = 20, g_M = 1u << 20, g_birth = 1u << 3, g_survive = 12u;
static volatile u32 bar_count, bar_gen;
static volatile u32 done_count;
static volatile u32 g_progress;          /* rows completed by worker 0; read by the host watchdog */



enum {
  OP_COPY = 1, OP_LIFE, OP_ROT, OP_NSUM, OP_SQ, OP_MUL, OP_MULC, OP_ADD, OP_ADDC,
  OP_ORC, OP_DADD, OP_SHIFT, OP_FROM2, OP_TO2, OP_MODJ
};

static inline u32 modM(u32 x) { return g_p == 2 ? (x & (g_M - 1u)) : (x % g_M); }

/* (a*b) mod M for a,b < M <= 2^21, using 10-bit chunks of b. */
static inline u32 mulmod(u32 a, u32 b) {
  if (g_p == 2) return (a * b) & (g_M - 1u);
  u32 hi = b >> 10, lo = b & 1023u;
  u32 r = (a * hi) % g_M;          /* < 2^31 */
  r = (r << 10) % g_M;             /* r < 2^21 -> r<<10 < 2^31 */
  return (r + (a * lo) % g_M) % g_M;
}
static inline u32 dadd(u32 a, u32 b) {
  if (g_p == 2) return a ^ b;
  u32 r = 0, pw = 1;
  for (u32 i = 0; i < g_n; i++) {
    u32 d = (a % g_p + b % g_p) % g_p;
    r += d * pw; pw *= g_p; a /= g_p; b /= g_p;
  }
  return r;
}

/* Returns 1 when the ring is usable: p prime, n >= 1, p^n <= 2^21 (2^20 exactly when p = 2). */
EXPORT(configure) u32 configure(u32 p, u32 n, u32 birth, u32 survive) {
  if (p < 2 || n < 1 || n > 21) return 0;
  for (u32 d = 2; d * d <= p; d++) if (p % d == 0) return 0;
  u64 m = 1; for (u32 i = 0; i < n; i++) { m *= p; if (m > (1u << 21)) return 0; }
  if (p == 2 && n != 20) return 0;
  g_p = p; g_n = n; g_M = (u32)m;
  g_birth = birth & 0x1FF; g_survive = survive & 0x1FF;
  return 1;
}
EXPORT(modulus) u32 modulus(void) { return g_M; }
/* Returns 1 when every instruction is in range (op, slots, args); 0 leaves the program empty. */
EXPORT(load_program) u32 load_program(u32 ni, u32 ns, u32 nf) {
  ninit = nstep = nfinal = 0;
  if (ni > MAXI || ns > MAXI || nf > MAXI || ni + ns + nf > MAXI) return 0;   /* no u32 wrap */
  for (u32 i = 0; i < ni + ns + nf; i++) {
    const u32 *q = prog + i * 5;
    if (q[0] < OP_COPY || q[0] > OP_MODJ || q[1] >= NSLOT || q[2] >= NSLOT || q[3] >= NSLOT) return 0;
    if (q[1] == q[2] || (q[1] == q[3] && (q[0] == OP_ADD || q[0] == OP_MUL || q[0] == OP_DADD))) return 0;
    if (q[0] == OP_ROT && q[4] > 7) return 0;
    if (q[0] == OP_MODJ && (q[4] < 1 || q[4] > g_n)) return 0;
  }
  ninit = ni; nstep = ns; nfinal = nf;
  return 1;
}
EXPORT(prog_ptr) u32 prog_ptr(void) { return (u32)(unsigned long)prog; }
EXPORT(slot_ptr) u32 slot_ptr(u32 s) { return (u32)(unsigned long)slot[s]; }
EXPORT(words) u32 words(void) { return WORDS; }

static void exec(const u32 *ins, u32 y0, u32 y1) {
  u32 op = ins[0], c = ins[4];
  u32 *o = slot[ins[1]];
  const u32 *a = slot[ins[2]], *b = slot[ins[3]];
  u32 i0 = y0 * W * L, i1 = y1 * W * L;
  switch (op) {
  case OP_COPY: for (u32 i = i0; i < i1; i++) o[i] = a[i]; break;
  case OP_ADD:  for (u32 i = i0; i < i1; i++) o[i] = modM(a[i] + b[i]); break;
  case OP_ADDC: { u32 cm = c % g_M; for (u32 i = i0; i < i1; i++) o[i] = modM(a[i] + cm); break; }
  case OP_ORC:  { u32 cm = c % g_M; for (u32 i = i0; i < i1; i++) o[i] = modM(a[i] | cm); break; }
  case OP_SQ:   for (u32 i = i0; i < i1; i++) o[i] = mulmod(a[i], a[i]); break;
  case OP_MUL:  for (u32 i = i0; i < i1; i++) o[i] = mulmod(a[i], b[i]); break;
  case OP_MULC: for (u32 i = i0; i < i1; i++) o[i] = mulmod(a[i], c % g_M); break;
  case OP_SHIFT:for (u32 i = i0; i < i1; i++) o[i] = mulmod(a[i], g_p % g_M); break;
  case OP_DADD: for (u32 i = i0; i < i1; i++) o[i] = dadd(a[i], b[i]); break;
  case OP_MODJ: { u32 m = 1; for (u32 k = 0; k < c; k++) m *= g_p; for (u32 i = i0; i < i1; i++) o[i] = a[i] % m; break; }
  case OP_FROM2: { u32 m1 = g_M / g_p; for (u32 i = i0; i < i1; i++) o[i] = g_p == 2 ? modM(a[i]) : (a[i] & 1u) + g_p * ((a[i] >> 1) % m1); break; }
  case OP_TO2:  for (u32 i = i0; i < i1; i++) o[i] = g_p == 2 ? a[i] : (((a[i] % g_p) & 1u) | (((a[i] / g_p) << 1) & 0xFFFFFu)); break;
  case OP_ROT:
    for (u32 cell = y0 * W; cell < y1 * W; cell++)
      for (u32 k = 0; k < L; k++) o[cell * L + k] = a[cell * L + ((k + c) & 7u)];
    break;
  case OP_NSUM: case OP_LIFE:
    for (u32 y = y0; y < y1; y++) {
      u32 ym = (y + H - 1) % H, yp = (y + 1) % H;
      for (u32 x = 0; x < W; x++) {
        u32 xm = (x + W - 1) % W, xp = (x + 1) % W;
        u32 nb[8] = { (ym * W + xm) * L, (ym * W + x) * L, (ym * W + xp) * L, (y * W + xm) * L,
                      (y * W + xp) * L, (yp * W + xm) * L, (yp * W + x) * L, (yp * W + xp) * L };
        u32 base = (y * W + x) * L;
        for (u32 k = 0; k < L; k++) {
          if (op == OP_NSUM) {
            u32 s = 0; for (u32 j = 0; j < 8; j++) s += a[nb[j] + k];
            o[base + k] = modM(s);
          } else {
            u32 live = 0; for (u32 j = 0; j < 8; j++) live += (a[nb[j] + k] % g_p) != 0;
            u32 alive = (a[base + k] % g_p) != 0;
            o[base + k] = alive ? ((g_survive >> live) & 1u) : ((g_birth >> live) & 1u);
          }
        }
      }
    }
    break;
  }
}

static void barrier(u32 nt) {
  if (nt <= 1) return;
#ifdef XPU_THREADS
  u32 gen = __atomic_load_n(&bar_gen, __ATOMIC_SEQ_CST);
  if (__atomic_add_fetch(&bar_count, 1, __ATOMIC_SEQ_CST) == nt) {
    __atomic_store_n(&bar_count, 0, __ATOMIC_SEQ_CST);
    __atomic_add_fetch(&bar_gen, 1, __ATOMIC_SEQ_CST);
    __builtin_wasm_memory_atomic_notify((int *)&bar_gen, 0xFFFFFFFFu);
  } else {
    while (__atomic_load_n(&bar_gen, __ATOMIC_SEQ_CST) == gen)
      __builtin_wasm_memory_atomic_wait32((int *)&bar_gen, (int)gen, -1);
  }
#endif
}

static void run_range(u32 first, u32 count, u32 y0, u32 y1, u32 nt, u32 tid) {
  for (u32 i = 0; i < count; i++) {
    exec(prog + (first + i) * 5, y0, y1); barrier(nt);
    if (tid == 0) __atomic_add_fetch(&g_progress, 1, __ATOMIC_RELAXED);
  }
}

EXPORT(progress_ptr) u32 progress_ptr(void) { return (u32)(unsigned long)&g_progress; }

/* Run the program: init once, step n times, final once. Worker tid of nt (1 <= nt <= H, tid < nt).
   Returns 0 when the request is refused. */
EXPORT(run) u32 run(u32 steps, u32 tid, u32 nt) {
  if (nt == 0 || nt > H || tid >= nt) return 0;
  u32 y0 = tid * H / nt, y1 = (tid + 1) * H / nt;
  run_range(0, ninit, y0, y1, nt, tid);
  for (u32 s = 0; s < steps; s++) run_range(ninit, nstep, y0, y1, nt, tid);
  run_range(ninit + nstep, nfinal, y0, y1, nt, tid);
  return 1;
}

/* per-worker stacks for the threaded build (each worker sets __stack_pointer) */
static unsigned char stacks[64][32768] __attribute__((aligned(16)));
EXPORT(stack_top) u32 stack_top(u32 t) { return (u32)(unsigned long)(stacks[t & 63] + 32768); }

EXPORT(reset_sync) void reset_sync(void) { bar_count = 0; bar_gen = 0; done_count = 0; g_progress = 0; }
