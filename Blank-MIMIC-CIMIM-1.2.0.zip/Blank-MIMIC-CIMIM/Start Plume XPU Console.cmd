@echo off
rem Starts the Plume XPU Console on 127.0.0.1:8788 (cross-origin isolated, so Wasm threads work)
rem and opens it in JA21 Blank Console. Edit the two paths below if your copies live elsewhere.
setlocal
set "HERE=%~dp0"
set "BLANK=C:\Users\russe\Downloads\unzipped\BLANK"
set "NODE=C:\Users\russe\Desktop\bytefoundry-0.99.2-win64\node-v22.23.4-win-x64\node.exe"
if not exist "%NODE%" set "NODE=node"
start "Plume XPU server" /min "%NODE%" "%HERE%serve.mjs"
timeout /t 1 /nobreak >nul
if exist "%BLANK%\host\Start-Console.ps1" (
  powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%BLANK%\host\Start-Console.ps1" -StartUrl "http://127.0.0.1:8788/"
) else (
  echo JA21 Blank Console not found at %BLANK% - opening your default browser instead.
  start "" "http://127.0.0.1:8788/"
)
endlocal
